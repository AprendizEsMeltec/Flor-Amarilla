<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🌻 Flor Amarilla</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <?php
    $nombre_amiga = "Givanny Melendez"; // Cambia este nombre por el de tu amiga
    $mensaje = "¡Feliz Día del Amor y Amistad xd!"; // Cambia este mensaje
    $fecha_hoy = date("d \\d\\e F \\d\\e Y");
    ?>
    
    <div class="container">
        <h1 class="titulo">Lo Prometido es Deuda, no se lo pude hacer cuando eramos relación pero aca esta, Un año tarde xddd🌻</h1>
        
        <div class="flor">
            <img src="img/flor_sao.png" alt="Flor estilo Sword Art Online" class="flor-sao">
            <div class="tallo">
                <div class="hoja izq"></div>
                <div class="hoja der"></div>
            </div>
        </div>
        
        <div class="mensaje">
            <?php echo $mensaje; ?>
        </div>
        
        <div class="submensaje">
            💐 Para: <strong><?php echo $nombre_amiga; ?></strong><br>
            📅 <?php echo $fecha_hoy; ?><br>
            🌸
        </div>
    </div>
</body>
</html>